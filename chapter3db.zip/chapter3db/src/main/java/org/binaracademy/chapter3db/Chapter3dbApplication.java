package org.binaracademy.chapter3db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter3dbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chapter3dbApplication.class, args);
	}

}
